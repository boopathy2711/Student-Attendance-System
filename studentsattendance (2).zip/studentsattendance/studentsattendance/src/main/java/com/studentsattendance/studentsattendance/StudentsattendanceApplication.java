package com.studentsattendance.studentsattendance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsattendanceApplication {
	public static void main(String[] args) {
		SpringApplication.run(StudentsattendanceApplication.class, args);
	}
}
