package com.studentsattendance.studentsattendance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsattendanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
